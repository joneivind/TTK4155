/*
 * PWM.h
 *
 * Created: 02.11.2017 17:55:45
 *  Author: kjettho
 */ 


#ifndef PWM_H_
#define PWM_H_

void TC_init();
void PWM_setDutyCycle(uint8_t xValue);

#endif /* PWM_H_ */