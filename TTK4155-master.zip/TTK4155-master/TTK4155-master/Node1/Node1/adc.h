/*
 * adc.h
 *
 * Created: 18.09.2017 14:37:54
 *  Author: kjettho
 */ 


#ifndef ADC_H_
#define ADC_H_

int adc(int channel);

#endif /* ADC_H_ */