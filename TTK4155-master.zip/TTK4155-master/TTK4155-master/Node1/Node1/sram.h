/*
 * sram.h
 *
 * Created: 11.09.2017 12:18:53
 *  Author: kjettho
 */ 

#ifndef SRAM_H_
#define SRAM_H_
#include <avr/io.h>

void sramTest(void);
void sramInit(void);

#endif /* SRAM_H_ */